CREATE PROCEDURE DropSequence(IN vname VARCHAR(30))
  BEGIN
     -- Drop the sequence
     DELETE FROM _sequences WHERE name = vname;
  END;

