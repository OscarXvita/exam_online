CREATE FUNCTION NextVal(vname VARCHAR(30))
  RETURNS INT
  BEGIN
     -- Retrieve and update in single statement
     UPDATE _sequences
       SET next = (@next := next) + 1
       WHERE name = vname;

     RETURN @next;
  END;

