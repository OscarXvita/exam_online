CREATE PROCEDURE CreateSequence(IN name VARCHAR(30), IN start INT, IN inc INT)
  BEGIN
     -- Create a table to store sequences
     CREATE TABLE IF NOT EXISTS _sequences
     (
         name VARCHAR(70) NOT NULL UNIQUE,
         next INT NOT NULL,
         inc INT NOT NULL
     );

     -- Add the new sequence
     INSERT INTO _sequences VALUES (name, start, inc);
  END;

